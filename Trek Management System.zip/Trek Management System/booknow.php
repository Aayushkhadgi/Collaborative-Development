<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Replace 'your_username' with your actual MySQL username
$password = ""; // Replace 'your_password' with your actual MySQL password
$database = "Trek_Management"; // Replace 'your_database' with your actual MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch data from the database using JOIN operation
function fetchData($conn) {
    $sql = "SELECT trek_destinations.*, package.name AS package_name, package.price AS package_price FROM trek_destinations 
            INNER JOIN package ON trek_destinations.package_id = package.package_id 
            ORDER BY trek_destinations.package_id ASC";
    $result = $conn->query($sql);
    $data = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

// Fetch trek destinations data
$trekDestinationsData = fetchData($conn);
if (!$trekDestinationsData) {
    echo "Error: " . $conn->error;
} else {
    // Debugging: Output the fetched data
    // print_r($trekDestinationsData);
}
$trekNames = array();

// Query to retrieve trek names for IDs 1 to 10
$sql = "SELECT * FROM trek_destinations WHERE id BETWEEN 1 AND 10";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch data and store in the array
    while ($row = $result->fetch_assoc()) {
        $trekNames[] = $row['name'];
    }
} else {
    echo "No results found.";
}

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration page</title>
    <link rel="stylesheet" href="booknow.css"/>
</head>
<body>
    <div class="container">
        <header>Registration Form</header>
        <form action="connect.php" method="post" class="form">
            <div class="input-box">
                <label>Full Name</label>
                <input type="text" placeholder="Enter full name" required pattern="[A-Za-z\s]+" title="Please enter only alphabets for full name" id="fullName" name="fullName"/>
            </div>
            <div class="input-box">
                <label>Email Address</label>
                <input type="email" placeholder="Enter email address" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" title="Please enter a valid email address"id="email" name="email"/>
            </div>
            <div class="column">
                <div class="input-box">
                    <label> Phone Number</label>
                    <input type="tel" placeholder="Enter phone number" required pattern="[0-9]{10,}" title="Please enter a valid 10-digit phone number" id="phoneNum" name="phoneNum"/>
                </div>
                <div class="input-box">
                    <label>Birth Date</label>
                    <input type="date" placeholder="Enter birth date" required id="birthDate" name="birthDate"/>
                </div>
            </div>
            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" checked value="m" />
                        <label for="check-male"> Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="f"/>
                        <label for="check-female"> Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-other" name="gender" value="o" />
                        <label for="check-other"> Prefer not to say</label>
                    </div>
                </div>
            </div>
            <div class="input-box address">
                <label>Address</label>
                <input type="text" placeholder="Enter street address" required id="address1" name="address1" />
                <input type="text" placeholder="Enter street address line 2 (optional)" id="address2" name="address2"/>
                <div class="column">
                    <div class="select-box">
                        <select name="country" id="countries">
                            <option hidden>Country</option>
                        </select>
                    </div>
                    <input type="text" placeholder="Enter your city" required id="city" name="city"/>
                </div>
                <div class="column">
                    <input type="text" placeholder="Enter your region" required id="region" name="region"/>
                    <input type="number" placeholder="Enter postal code" required pattern="[0-9]{5}" id="postalCode" name="postalCode"/>
                </div>
                <div class="column">
                    <div class="select-box">
                        <select name="Trek" id="Trek" name="Trek">
                            <option hidden>Select Trek</option>
                            <?php foreach ($trekNames as $trek): ?>
                                <option><?php echo $trek; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="select-box">
                        <select name="package" id="package">
                            <option hidden>Select Package</option>
                            <?php
                            $uniquePackages = array();
                            foreach($trekDestinationsData as $destination) {
                                $packageKey = $destination['package_name'] . ' - $' . $destination['package_price'];
                                if (!in_array($packageKey, $uniquePackages)) {
                                    $uniquePackages[] = $packageKey;
                            ?>
                            <option value="<?php echo $destination['package_id']; ?>">
                                <?php echo $packageKey; ?>
                            </option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="input-box extra-facilities">
                    <label>Extra facilities (optional)</label>
                    <input type="text" placeholder="Enter extra facilities you want to add in your package" id="extraFacilities" name="extraFacilities"/>
                </div>
            </div>
            <button type="submit">Submit</button>
        </form>
        <div class="login-link-container">
            
        <p>Already Registered? <a href="loginnow.php" class="login-link">Login</a></p>
        </div>
    </div>
    <script src="booknow.js"></script>
</body>
</html>
