<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$database = "Trek_Management";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch data from the database
function fetchData($conn, $tableName) {
    $sql = "SELECT * FROM $tableName";
    $result = $conn->query($sql);
    $data = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}

// Fetch include/exclude data
$includeExcludeData = fetchData($conn, "Include_Exclude");



// Fetch daily schedule data for id
$sql = "SELECT daily_schedule FROM trek_destinations WHERE id = 9";
$result = $conn->query($sql);
$dailyScheduleData = $result->fetch_assoc();

// Fetch map data
$sql = "SELECT * FROM trek_destinations WHERE id = 9";
$result = $conn->query($sql);
$mapData = $result->fetch_assoc();


$sql = "SELECT td.location, td.duration, td.daily_activity, td.best_time, td.transportation, td.accommodation, td.max_altitude, g.type AS grade_type
        FROM trek_destinations td
        INNER JOIN grade g ON td.grade_id = g.grade_id
        WHERE td.id = 9";
$result = $conn->query($sql);
$trekDestinationData = $result->fetch_assoc();

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="EBC.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="slide1">
            
        <div class="panel1">
            <h1> Kanchanjunga Trek </h1>
    <?php if ($result->num_rows > 0) : ?>
        <?php foreach($result as $row) : ?>
            <div class="logo-container">
                <div class="logo-row">
                    <div class="logo-item">
                        <img src="location.png" alt="Logo 1">
                        <div class="logo-details">
                            <h3>Location</h3>
                            <p><?php echo $row['location']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="accomodation.png" alt="Logo 2">
                        <div class="logo-details">
                            <h3>Accommodation</h3>
                            <p><?php echo $row['accommodation']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="grade.png" alt="Logo 3">
                        <div class="logo-details">
                            <h3>Grade</h3>
                            <p><?php echo $row['grade_type']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="duration.png" alt="Logo 4">
                        <div class="logo-details">
                            <h3>Duration</h3>
                            <p><?php echo $row['duration']; ?></p>
                        </div>
                    </div>
                </div>
                <div class="logo-row">
                    <div class="logo-item">
                        <img src="daily-activity.png" alt="Logo 5">
                        <div class="logo-details">
                            <h3>Daily Activity</h3>
                            <p><?php echo $row['daily_activity']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="max-altitude.png" alt="Logo 6">
                        <div class="logo-details">
                            <h3>Max Altitude</h3>
                            <p><?php echo $row['max_altitude']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="season.png" alt="Logo 7">
                        <div class="logo-details">
                            <h3>Best Time</h3>
                            <p><?php echo $row['best_time']; ?></p>
                        </div>
                    </div>
                    <div class="logo-item">
                        <img src="transportation.png" alt="Logo 8">
                        <div class="logo-details">
                            <h3>Transportation</h3>
                            <p><?php echo $row['transportation']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <p>No trek destinations found.</p>
    <?php endif; ?>
</div>
        </div>

        <!-------------slide-2------------->

        <div class="slide2">
            <div class="button">

                <div class="button1">
                    <button id="trekButton">
                        <img src="itenary.png" alt="Logo 1">
                        <span>Trek Itinerary</span>
                    </button>
                </div>
        
                <div class="button2">
                    <button id="includeExcludeButton">
                        <img src="include.png" alt="Logo 2">
                        <span>Include/Exclude</span>
                    </button>
                </div>
                <div class="button3">
                    <button id="mapButton">
                        <img src="map.png" alt="Logo 3">
                        <span>map</span>
                    </button>
                </div>
                <div class="button4">
    <a href="book.php">
        <button id="shopButton">
            <img src="file.png" alt="Logo 4">
            <span>Book</span>
        </button>
    </a>
</div>
            </div>
        
            <div id="trekPanel" class="panel">
    <h1>Your Daily Schedule</h1>
    <div class="schedule-table">
        <?php
        // Check if daily schedule data is available
        if (!empty($dailyScheduleData['daily_schedule'])) {
            // Explode the schedule into an array of lines
            $scheduleLines = explode("*", $dailyScheduleData['daily_schedule']);
            // Output each schedule line
            foreach ($scheduleLines as $scheduleLine) {
                // Trim the line to remove leading/trailing whitespace
                $trimmedLine = trim($scheduleLine);
                // Output the trimmed line
                echo "<div class='schedule-row'>";
                echo "<div class='details'>$trimmedLine</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='no-data'>No schedule data available.</div>";
        }
        ?>
    </div>
</div>

            <div id="includeExcludePanel" class="panel">
                <div class="pan1">
                    <h1>Included</h1>
                    <p>
                        <?php foreach ($includeExcludeData as $item): ?>
                            <?php if ($item['category'] === 'Included'): ?>
                                <?php echo $item['details']; ?><br>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </p>
                </div>
                <div class="pan2">
                    <h1>Not-included</h1>
                    <p>
                        <?php foreach ($includeExcludeData as $item): ?>
                            <?php if ($item['category'] === 'Not-included'): ?>
                                <?php echo $item['details']; ?><br>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </p>
                </div>
            </div>
            <div id="mapPanel" class="panel">
                <!-- Content for trek itinerary panel -->
                <img src="<?php echo isset($mapData['map_image']) ? $mapData['map_image'] : ''; ?>" alt=" map">
            </div>
        </div>
    </div>
    <script src="LV.js"></script>

</body>
</html>
