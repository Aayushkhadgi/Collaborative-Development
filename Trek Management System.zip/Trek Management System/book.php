<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Replace 'your_username' with your actual MySQL username
$password = ""; // Replace 'your_password' with your actual MySQL password
$database = "Trek_Management"; // Replace 'your_database' with your actual MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch data from the database
function fetchData($conn, $tableName) {
    $sql = "SELECT * FROM $tableName";
    $result = $conn->query($sql);
    $data = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}
// Function to fetch data from the database based on ID

// Fetch package data
$packageData = fetchData($conn, "package");

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Package</title>
    <style>
        .panelX, .panelY, .panelZ {
            width: 100%;
            max-width: 350px; /* Adjusted max-width for panels */
        }
        .button-container {
            width: 100%;
            display: flex;
            justify-content: center;
            position: absolute;
            bottom: 20px; /* Adjust the distance from the bottom as needed */
            left: 0;
            right: 0;
        }

        .panel-button {
            padding: 10px 20px;
            background-color: #fff;
            color: #000;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .panel-button:hover {
            background-color: lavender;
        }
        /*--------------Slide 3----------*/
        .slide3{
            width: 100%;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url("https://png.pngtree.com/background/20230611/original/pngtree-the-top-of-the-everest-mountain-is-surrounded-by-clouds-picture-image_3171363.jpg");
            background-size: cover; /* Ensures the background image covers the entire element */
            background-position: center; /* Centers the background image */
            position: relative;
        }
        
        .panalA {
            display: flex;
            align-items: center;
            justify-content: space-around; /* Ensure panels are spaced evenly */
            gap: 40px;
        }
        a{
            text-decoration: none;
        }
        .panelX, .panelY, .panelZ {
    height: auto; /* Change height to auto */
    border-radius: 40px;
    background-color: #d9d9d9;
    opacity: 79%;
    align-items: center;
    justify-content: center;
    position: relative;
    padding: 40px;
    display: flex;
    flex-direction: column;
    border-top-left-radius: 0px;
    border-bottom-right-radius: 0px;
    border-top-right-radius: 90px;
    border-bottom-left-radius: 90px;
    margin: 0 10px; /* Add margin to create space between panels */
    
    transition: transform 0.3s; /* Added transition for scale effect */
}

        
        .panelX:hover, .panelY:hover, .panelZ:hover {
            transform: scale(1.05); /* Enlarge the panel by 5% on hover */
        }
        
        .panelX h1, .panelY h1, .panelZ h1 {
            font-style:normal ;
            font-size: 40px;
        }
        
        .panelX h2, .panelY h2, .panelZ h2 {
            font-style:normal ;
            font-size: 50px;
        }
        
        .panelX p, .panelY p, .panelZ p {
            font-style:normal ;
            font-size: 15px;
        }
        
               
                @media only screen and (max-width: 768px) {
                    .panalA {
                        flex-direction: column;
                        align-items: center;
                    }
                
                    .panelX, .panelY, .panelZ {
                        max-width: 75%;
                        margin-bottom: 20px;
                    }
                
                    .panel-content {
                        overflow-y: auto; /* Add overflow to handle content overflow */
                        max-height: 300px; /* Adjust the max-height as needed */
                        padding-right: 10px; /* Add some padding to prevent content from being hidden by the scrollbar */
                    }
                }
        @media (max-width: 947px){
            .panalA {
                flex-direction: column;
                align-items: center;
            }
            .panelX, .panelY, .panelZ {
                max-width: 90%;
                margin-bottom: 20px;
            }
            .panelX h1, .panelY h1, .panelZ h1 {
                font-size: 30px;
            }
            .panelX h2, .panelY h2, .panelZ h2 {
                font-size: 40px;
            }
            .panelX p, .panelY p, .panelZ p {
                font-size: 11px;
            }
        }
        
        @media (max-width: 500px) {
            .panelX h1, .panelY h1, .panelZ h1 {
                font-size: 25px;
            }
            .panelX h2, .panelY h2, .panelZ h2 {
                font-size: 30px;
            }
            .panelX p, .panelY p, .panelZ p {
                font-size: 10px;
            }
        }
    </style>
</head>
<body>
<div class="slide3">
        <div class="panalA">
            <div class="panelX">
                <?php foreach($packageData as $package): ?>
                    <?php if ($package['package_id'] == 1): ?>
                        <h1><?php echo $package['name']; ?></h1>
                        <p><?php echo $package['facility']; ?></p>
                        <h2><?php echo $package['price']; ?></h2>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="panalA">
            <div class="panelY">
                <?php foreach($packageData as $package): ?>
                    <?php if ($package['package_id'] == 2): ?>
                        <h1><?php echo $package['name']; ?></h1>
                        <p><?php echo $package['facility']; ?></p>
                        <h2><?php echo $package['price']; ?></h2>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="panalA">
            <div class="panelZ">
                <?php foreach($packageData as $package): ?>
                    <?php if ($package['package_id'] == 3): ?>
                        <h1><?php echo $package['name']; ?></h1>
                        <p><?php echo $package['facility']; ?></p>
                        <h2><?php echo $package['price']; ?></h2>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="button-container">
        <a href="#" class="panel-button" id="bookNowButton">Book Now</a>
    </div>

    <script>
        document.getElementById("bookNowButton").addEventListener("click", function() {
            window.location.href = "booknow.php";
        });
    </script>
    </div>
</body>
</html>
