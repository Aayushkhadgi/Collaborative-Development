document.addEventListener('DOMContentLoaded', () => {
  const selectDrop = document.getElementById('countries');

  fetch('https://restcountries.com/v3.1/all')
    .then(response => response.json())
    .then(data => {
      data.forEach(country => {
        const option = document.createElement('option');
        option.text = country.name.common;
        option.value = country.name.common;
        selectDrop.add(option);
      });
    })
    .catch(error => {
      console.error('Error fetching countries:', error);
    });
});

// Assuming you have an array of packages data
var packagesData = [
  { name: "Basic", location: "Location1" },
  { name: "Advanced", location: "Location1" },
  { name: "Premium", location: "Location2" },
  // Add more packages data as needed
];

// Function to populate package options based on selected location
function populatePackages(location) {
  var packageSelect = document.getElementById("package");
  packageSelect.innerHTML = '<option hidden>Select Package</option>';
  
  packagesData.forEach(function(pkg) { // Changed variable name from package to pkg
      if (pkg.location === location) { // Changed variable name from package to pkg
          var option = document.createElement("option");
          option.textContent = pkg.name; // Changed variable name from package to pkg
          packageSelect.appendChild(option);
      }
  });
}
