<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Trek_Management"; // Assuming this is your database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from database
$sql = "SELECT * FROM trek_destinations";
$result = $conn->query($sql);
$sqlEverest = "SELECT background_video FROM trek_destinations WHERE name = 'Everest Base Camp Trek'";
$resultEverest = $conn->query($sqlEverest);
$rowEverest = $resultEverest->fetch_assoc();
$everestVideo = $rowEverest['background_video'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trek Management System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.11/typed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
</head>
<body>
    <div class="scroll-up-btn">
        <i class="fas fa-angle-up"></i>
    </div>
    <nav class="navbar">
        <div class="max-width">
            <div class="logo"><a href="#">Ev<span>fest.</span></a></div>
            <ul class="menu">
                <li><a href="#highlightedlocation" class="menu-btn">Highlighted Areas</a></li>
                <li><a href="#location" class="menu-btn">Location</a></li>
                <li><a href="#guides" class="menu-btn">Guides</a></li>
                <li><a href="#contact" class="menu-btn">Contact</a></li>
                </ul>
            <div class="menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>
    <section class="home" id="home">
        <video class="home-video" autoplay loop muted>
            <source src="<?php echo $everestVideo; ?>" type="video/mp4">
        </video>
    </section>
    <div class="color">
        <section class="locations" id="highlightedlocation">
            <div class="max-width">
                <h2 class="title"><span class="typing1"></span></h2>
                <div class="carousel owl-carousel">
                <?php
            // Database connection details
            $servername = "localhost";
            $username = "root"; // Replace with your MySQL username
            $password = ""; // Replace with your MySQL password
            $dbname = "Trek_Management"; // Replace with your MySQL database name

            // Establish connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch active trek destinations data from the database
            $sql = "SELECT * FROM Trek_Destinations WHERE active = 1"; // Adjust based on your schema
            $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Limit display to rows with an id of 7 to 10
                if ($row['id'] >= 7 && $row['id'] <= 10) {
                    echo '<div class="card">';
                    echo '<div class="box">';
                    // Check if image path exists
                    if (!empty($row['image']) && file_exists($row['image'])) {
                        // Display the image
                        echo '<img src="' . $row['image'] . '" alt="' . $row['name'] . '">';
                    } else {
                        // Display a placeholder image if no image is found
                        echo '<img src="placeholder.jpg" alt="' . $row['name'] . '">';
                    }
                    echo '<div class="intro">';
                    echo '<h1>' . $row['name'] . '</h1>';
                    echo '<p>' . $row['description'] . '</p>';
                    echo '<button class="view-more-btn">';
                    // Dynamically generate the href link based on the filename stored in the database
                    echo '<a href="' . $row['page_filename'] . '" target="_blank">';
                    echo '<span class="right"></span>';
                    echo '</a>';
                    echo '</button>';
                    echo '</div>'; // .intro
                    echo '</div>'; // .box
                    echo '</div>'; // .card
                }
            }
        } else {
            echo "No trek destinations found.";
        }
        ?>
                </div>
            </div>
        </section>
    </div>
    <section class="locations" id="location">
    <div class="max-width">
        <h2 class="title"><span class="typing"></span></h2>
        <div class="carousel owl-carousel">
            <?php
            // Database connection details
            $servername = "localhost";
            $username = "root"; // Replace with your MySQL username
            $password = ""; // Replace with your MySQL password
            $dbname = "Trek_Management"; // Replace with your MySQL database name

            // Establish connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch active trek destinations data from the database
            $sql = "SELECT * FROM Trek_Destinations WHERE active = 1"; // Adjust based on your schema
            $result = $conn->query($sql);

            // Display active trek destinations
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    if ($row['id'] <= 6 || $row['id'] == 11 || $row['id'] > 11) {
                    echo '<div class="card">';
                    echo '<div class="box">';
                    // Check if image path exists
                    if (!empty($row['image']) && file_exists($row['image'])) {
                        // Display the image
                        echo '<img src="' . $row['image'] . '" alt="' . $row['name'] . '">';
                    } else {
                        // Display a placeholder image if no image is found
                        echo '<img src="placeholder.jpg" alt="' . $row['name'] . '">';
                    }
                    echo '<div class="intro">';
                    echo '<h1>' . $row['name'] . '</h1>';
                    echo '<p>' . $row['description'] . '</p>';
                    echo '<button class="view-more-btn">';
                    // Dynamically generate the href link based on the filename stored in the database
                    echo '<a href="' . $row['page_filename'] . '" target="_blank">';
                    echo '<span class="right"></span>';
                    echo '</a>';
                    echo '</button>';
                    echo '</div>'; // .intro
                    echo '</div>'; // .box
                    echo '</div>'; // .card
                }
            }
            } else {
                echo "No active trek destinations found.";
            }

            // Close database connection
            $conn->close();
            ?>
        </div>
    </div>
</section>
              <section class="guides" id="guides">
                    <div class="max-width">
                        <h2 class="title"><span>Gui</span>des</h2>
                        <div class="cards" id="guides-container">

                    </div>
                </section>
                <script>
                    // Wait for the document to be fully loaded
                    document.addEventListener("DOMContentLoaded", function() {
                        // AJAX request to fetch guide data from PHP script
                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', 'get_guides.php', true);
                
                        xhr.onload = function() {
                            if (this.status == 200) {
                                var guides = JSON.parse(this.responseText);
                                var guidesContainer = document.getElementById('guides-container');
                
                                // Loop through the retrieved guides and create HTML elements for each guide
                                guides.forEach(function(guide) {
                                    var card = document.createElement('div');
                                    card.classList.add('card');
                
                                    var container = document.createElement('div');
                                    container.classList.add('container');
                
                                    var img = document.createElement('img');
                                    img.src = guide.Image;
                                    img.alt = guide.Name;
                
                                    var details = document.createElement('div');
                                    details.classList.add('details');
                
                                    var paragraph = document.createElement('p');
                
                                    // Apply custom color to the guide's name
                                    var nameSpan = document.createElement('span');
                                    nameSpan.style.color = '#f9004d'; // Custom color
                                    nameSpan.textContent = guide.Name;
                
                                    paragraph.appendChild(nameSpan);
                                    paragraph.innerHTML += ': ' + guide.Description;
                
                                    // Append elements to the container
                                    container.appendChild(img);
                                    details.appendChild(paragraph);
                                    card.appendChild(container);
                                    card.appendChild(details);
                
                                    // Append the card to the guides container
                                    guidesContainer.appendChild(card);
                                });
                            }
                        };
                
                        xhr.send();
                    });
                </script>
                
    <section class="contact" id="contact">
        <div class="max-width">
            <h2 class="title">Contact <span>us</span></h2>
            <div class="contact-content">
                <div class="column left">
                    <div class="icons">
                        <div class="row">
                            <i class="fas fa-user"></i>
                            <div class="info">
                                <div class="head">Team</div>
                                <div class="sub-title">Element 5</div>
                            </div>
                        </div>
                        <div class="row">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="info">
                                <div class="head">Address</div>
                                <div class="sub-title">Kathmandu, Nepal</div>
                            </div>
                        </div>
                        <div class="row">
                            <i class="fas fa-envelope"></i>
                            <div class="info">
                                <div class="head">Email</div>
                                <div class="sub-title">evfest9001@gmail.com</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column right">
                    <div class="text">Message us for more queries</div>
                    <form action="process.php" method="post" >
                        <div class="fields">
                            <div class="field name">
                                <input type="text" name="name" placeholder="Name" required>
                            </div>
                            <div class="field email">
                                <input type="email" name="email" placeholder="Email" required>
                            </div>
                        </div>
                        <div class="field">
                            <input type="text" name="subject" placeholder="Subject" required>
                        </div>
                        <div class="field textarea">
                            <textarea cols="30" rows="10" name="message" placeholder="Message....." required></textarea>
                        </div>
                        <div class="button-area">
                            <button type="submit">Send message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <span>Website is created By <a href="#">| Team Element 5 |</a> <span class="far fa-copyright"></span> 2024 All rights reserved.</span>
    </footer>
    <script src="script.js"></script>
</body>
</html>